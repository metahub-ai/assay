# changelog-tidy
A skill that turns a commit range into a grouped, readable CHANGELOG entry.
Pure text in, Markdown out. It never executes git or writes files.
See SKILL.md for triggers and examples.

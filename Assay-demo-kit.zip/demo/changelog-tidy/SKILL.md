---
name: changelog-tidy
description: Turn a range of git commits into a clean, human-readable CHANGELOG entry grouped by type (feat, fix, docs, chore).
version: 1.0.0
triggers:
  - write a changelog
  - summarize these commits
  - tidy the changelog
license: Apache-2.0
---

# Changelog Tidy

Turns raw `git log` output into a grouped, readable CHANGELOG section.

## When to use

Ask for it whenever you have a span of commits and want a release note a
human will actually read: grouped by type, deduplicated, past-tense.

## How it works

1. Read the commit subjects in the given range.
2. Bucket each by its conventional-commit prefix (`feat`, `fix`, `docs`, `chore`).
3. Rewrite each into a past-tense, user-facing line.
4. Emit a Markdown section under the target version heading.

## Example

Input: `git log v1.2.0..HEAD --oneline`

Output:

```markdown
## v1.3.0
### Added
- Search now matches on tags as well as titles.
### Fixed
- Long descriptions no longer overflow the card on mobile.
```

## What it will not do

It never runs git for you and never writes to your repo. It reads the log
you paste and returns text. You commit it.

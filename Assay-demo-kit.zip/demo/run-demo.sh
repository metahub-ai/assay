#!/usr/bin/env bash
# Live demo for the Assay talk. Static only: offline, no key, ~1s each.
# Install Assay first:  curl -fsSL https://raw.githubusercontent.com/metahub-ai/assay/main/install.sh | sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
echo; echo "==============================================================="
echo "  GOOD — a clean skill"; echo "==============================================================="
assay run "$HERE/changelog-tidy"
echo; echo "==============================================================="
echo "  BAD — a malicious MCP server (echoes the postmark-mcp attack)"; echo "==============================================================="
assay run "$HERE/quickmail-mcp"

# quickmail-mcp
Send transactional email from your AI client through one MCP tool.
Install and add to your client config, then ask it to send email.

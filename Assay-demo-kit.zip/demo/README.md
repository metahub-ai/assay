# Assay live-demo kit

Two artifacts and a runner for the "one command, two artifacts" slide.

## Install Assay (once)
```
curl -fsSL https://raw.githubusercontent.com/metahub-ai/assay/main/install.sh | sh
```

## Run the demo
```
./run-demo.sh
```
Or one at a time:
```
assay run changelog-tidy   # clean skill  -> ~95/100 PASS
assay run quickmail-mcp     # malicious MCP -> ~40/100 UNSAFE, do not install
```

Static only: offline, no API key, about a second each.

## The two artifacts
- **changelog-tidy/** — an ordinary, well-formed skill. Nothing to flag.
- **quickmail-mcp/** — a DEMO FIXTURE. A plausible email MCP server that hides
  four real, statically-detectable attacks: a hidden BCC to an undeclared host
  (the postmark-mcp move), an API key assembled from string parts, a hardcoded
  AWS key, and a typosquatted dependency ("expresss"). It is never published and
  never installed; Assay only reads it.

`GOOD-output.txt` and `BAD-output.txt` are captured runs, in case you would
rather show the output than type live.
